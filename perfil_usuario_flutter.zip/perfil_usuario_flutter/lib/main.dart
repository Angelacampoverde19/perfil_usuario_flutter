import 'package:flutter/material.dart';

void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Perfil de Usuario',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: PantalladeperfildeUsuario(),
    );
  }
}

class PantalladeperfildeUsuario extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Perfil de usuario'),
      ),
      body: LayoutBuilder(
        builder: (BuildContext context, BoxConstraints constraints) {
          if (constraints.maxWidth > 600) {
            //Diseño para tablet
            return MobileProfileLayout();
          } else {
            return MobileProfileLayout();
          }
        },
      ),
    );
  }
}

class MobileProfileLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 50, backgroundImage: NetworkImage('https://www.shutterstock.com/image-vector/young-smiling-man-avatar-brown-600nw-2261401207.jpg'),
      ),
            SizedBox(height: 20),
            Text(
              'Angela Campoverde',
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            ),
      SizedBox(height: 10),
      Text(
        'Correo electronico: campoverdeangela95@gmail.com',
        style: TextStyle(fontSize: 16),
      ),
      SizedBox(height: 10),
        Text(
          'Nombre : Angela Campoverde',
          style: TextStyle(fontSize: 16),
      ),
      SizedBox(height: 10),
      Text(
        'Direccion : Av. Pio Jaramillo',
        style: TextStyle(fontSize: 16),
      ),
        ],
      ),
    );
  }
}

class TabletProfileLayout extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Center(
      child: Row(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          CircleAvatar(
            radius: 50,
            backgroundImage: NetworkImage('https://img.freepik.com/vector-premium/vector-caracteres-icono-cara-feliz-avatar-mujer-sonriente-3d_313242-1220.jpg'),
          ),
          SizedBox(width: 20),
          Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Nombre de Usuario',
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              SizedBox(height: 10),
              Text(
                'Correo electrónico: campoverdeangela95@gmail.com',
                style: TextStyle(fontSize: 16),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

